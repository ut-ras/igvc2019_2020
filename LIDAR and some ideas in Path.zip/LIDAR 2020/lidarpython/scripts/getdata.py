#!/usr/bin/env python3
import rospy
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from sensor_msgs.msg import LaserScan


#This program just receives the Lidar laserscan data, output a continuous plot that shows the angle with largest distance without obstacle (I called it leastangle)
#The plot is just used for debug purposes/visualization of the outputs of the LIDAR.


#Clamps any distance between [dmin,dmax]
dmin = 0.2
dmax = 50

anglerange = 4 #using a sliding 1 degree range/window to average the distances, and calculate the leastngle.  4 because each iteration i in range(0,1081) rerepsents 0.25 degrees.
leastangle = 0 #It is the angle that has least resistance, meaning the angle with the largest distance without obstacle. 

def callback(data):  
	nextangle = -1
	sumofdist = 0
	avgdist = 0 
	prevavgdist = 0
	global leastangle
	#print(len(data.ranges))
	#print(data.header.seq)
	#dmin = data.range_min
	#dmax = data.range_max 
	for i in range(0,1081):  

		if i < nextangle:
			dist[i] = distprev + slope*(nextangle-i)
			sumofdist += dist[i]
			#print("HEY prevdist{}, dist{}".format(distprev,dist[i]))
			continue  


		if data.intensities[i] == 0: #invalid data
			distprev = dist[i-1]
			#look for the next angle whose intensity is not 0
			nextangle = min(i+1,1080)
			while data.intensities[nextangle] == 0 and nextangle != 1080:
				nextangle += 1

			#Found the next angle with non zero intensity, use this angle distance and the previous angle distance to do linear interpolation.	
			distnext = dist[nextangle]
			slope = (distnext - distprev)/(nextangle - i)
			#Doing linear interpolation from previous dist to next dist from angle i to nextangle, fixed point unit 0.25 angle
			dist[i] = distprev + slope*(nextangle - i)
			sumofdist += dist[i]
			#print("SLOPE IS ",slope) 
			continue

		#Clamping. 
		tempdist = data.ranges[i]
		if tempdist > dmax:
			tempdist = dmax
		elif dmin > tempdist : 
			tempdist = dmin
		dist[i] = tempdist
		sumofdist += dist[i]

		#Calculation of least average angle path
		if i == anglerange-1:
			avgdist = sumofdist/anglerange
		elif i > anglerange-1:  #Sliding the angle window to calculate the average distance.
			sumofdist -= dist[i-anglerange] #move forward the sum of angle 
			avgdist = sumofdist/anglerange
		#calculation of least angle
		if avgdist > prevavgdist:
			prevavgdist = avgdist
			leastangle = (i-2)*0.25 - 135


        
#	for i in range(0,1081):
#		print("angle{}, dist{}, intensity{}".format(angles[i],dist[i],data.intensities[i]))


#for matplotlib

def periodicfunc(i,dist):
	print(leastangle)
	line.set_ydata(dist)
	title.set_text("Least Resistance Angle : {}".format(leastangle))
	return line,title


if __name__ == '__main__':
    
	rospy.init_node('listener',anonymous=True)
	rospy.Subscriber("/scan",LaserScan,callback)
    
    #initialize empty line object annd the plot
	angles = list(np.arange(-135,135.25,0.25))
	angleslen = len(angles)
	dist = [0]*angleslen
	fig,ax = plt.subplots(1,1)
	ax.set_ylim(0,dmax)
	ax.set_title("Distance vs angle")
	title = ax.text(0.5,0.85, "", bbox={'facecolor':'w', 'alpha':0.5, 'pad':5},transform=ax.transAxes, ha="center")
	ax.set_xlabel("angle")
	ax.set_ylabel("distance")
	ax.set_xticks(range(-135,136,5))
	ax.tick_params(axis = 'x', labelrotation = 90)
	line, = ax.plot(angles,dist)
	
	ani = animation.FuncAnimation(fig,periodicfunc,fargs=(dist,),interval = 50, blit = True)
	plt.show()
    
	while(1):
		rospy.spin()

 

"""      
#polar plot. doesnt work well.
def periodicfunc(i,dist):
	print(leastangle)
	line.set_ydata(dist)
	title.set_text("Least Resistance Angle : {}".format(leastangle))
	return line,title

if __name__ == '__main__':

	rospy.init_node('listener',anonymous=True)
	rospy.Subscriber("/scan",LaserScan,callback)
	#initialize empty line object annd the plot
	angles = list(np.arange(-135,135.25,0.25))
	angleslen = len(angles)
	dist = [0]*angleslen
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='polar')
	ax.set_title("Distance vs angle")
	title = ax.text(0.5,0.85, "", bbox={'facecolor':'w', 'alpha':0.5, 'pad':5},transform=ax.transAxes, ha="center")
	ax.set_rmax(dmax)
	ax.set_theta_zero_location("N")
	ax.set_theta_direction('clockwise')
	ax.set_thetamin(-135)
	ax.set_thetamax(135)
	ax.set_thetagrids(range(-135,135,5))
	line, = ax.plot(angles,dist)
	ani = animation.FuncAnimation(fig,periodicfunc,fargs=(dist,),interval = 50,blit=True)
	plt.show()
    
	while(1):
		rospy.spin()


"""






